from .client import *
from .block import *
from .collection import NotionDate

def test():
    token_v2 ="9acf53bca42d96c8b3f61023708f50870da6033c927e45f9667d6dc0443a44c35744b10c5005b2e6939be90c312a4a2b3262c54b7102735494c63f271f547c70196a05d0d0a89ae063678b8f34b7"
    client = NotionClient(token_v2=token_v2)
    res = client.search_blocks(search="01803064")
    print(res)

